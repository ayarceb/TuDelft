
f1=figure(1); 
plot([1 2 3],[2 4 6]);
f2=figure(2);  
plot([4 2 3],[2 1 6]);